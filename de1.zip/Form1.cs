﻿namespace de1
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void dgvData_CellClick(object sender, DataGridViewCellEventArgs e)
        {
            txtId.Text = dgvData.Rows[e.RowIndex].Cells[0].Value.ToString();
            txtName.Text = dgvData.Rows[e.RowIndex].Cells[1].Value.ToString();
            txtPrice.Text = dgvData.Rows[e.RowIndex].Cells[2].Value.ToString();
            txtQuantity.Text = dgvData.Rows[e.RowIndex].Cells[3].Value.ToString();
            txtDescription.Text = dgvData.Rows[e.RowIndex].Cells[4].Value.ToString();
        }

        private void btnLoad_Click(object sender, EventArgs e)
        {
            using (var context = new BookDbContext())
            {
                var books = context.Books.ToList();
                dgvData.DataSource = books;
            }
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            using (var context = new BookDbContext())
            {
                var book = new Book
                {
                    Name = txtName.Text,
                    Description = txtDescription.Text
                };

                if (decimal.TryParse(txtPrice.Text, out decimal price))
                {
                    book.Price = price;
                }
                else
                {
                    MessageBox.Show("Giá trị Price không hợp lệ. Vui lòng nhập số.");
                    return;
                }

                if (int.TryParse(txtQuantity.Text, out int quantity))
                {
                    book.Quantity = quantity;
                }
                else
                {
                    MessageBox.Show("Giá trị Quantity không hợp lệ. Vui lòng nhập số nguyên.");
                    return;
                }

                context.Books.Add(book);
                context.SaveChanges();
            }

            btnLoad.PerformClick();
        }

        private void btnUpdate_Click(object sender, EventArgs e)
        {
            using (var context = new BookDbContext())
            {
                var book = context.Books.FirstOrDefault(p => p.Id == int.Parse(txtId.Text));
                if (book != null)
                {
                    if (decimal.TryParse(txtPrice.Text, out decimal price))
                    {
                        book.Price = price;
                    }
                    else
                    {
                        MessageBox.Show("Giá trị Price không hợp lệ. Vui lòng nhập số.");
                        return;
                    }

                    if (int.TryParse(txtQuantity.Text, out int quantity))
                    {
                        book.Quantity = quantity;
                    }
                    else
                    {
                        MessageBox.Show("Giá trị Quantity không hợp lệ. Vui lòng nhập số nguyên.");
                        return;
                    }

                    book.Name = txtName.Text;
                    book.Description = txtDescription.Text;
                    context.SaveChanges();
                }
                btnLoad.PerformClick();
            }
        }

        private void btnDelete_Click(object sender, EventArgs e)
        {
            using (var context = new BookDbContext())
            {
                var book = context.Books.FirstOrDefault(p => p.Id == int.Parse(txtId.Text));
                if (book != null)
                {
                    context.Books.Remove(book);
                    context.SaveChanges();
                }
                btnLoad.PerformClick();
            }
        }

        private void btnSearch_Click(object sender, EventArgs e)
        {
            string name = txtSearch.Text.Trim();

            if (!string.IsNullOrEmpty(name))
            {
                using (var context = new BookDbContext())
                {
                    var searchResults = context.Books
                                               .Where(b => b.Name.Contains(name))
                                               .ToList();

                    dgvData.DataSource = searchResults;
                }
            }
            else
            {
                MessageBox.Show("Vui lòng nhập tên sách để tìm kiếm.");
            }
        }
    }
}
