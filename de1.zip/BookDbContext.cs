﻿using Microsoft.EntityFrameworkCore;
using Microsoft.Extensions.Options;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Security.Cryptography;
using System.Text;
using System.Threading.Tasks;


namespace de1
{
    internal class BookDbContext : DbContext
    {
        protected override void OnConfiguring(DbContextOptionsBuilder optionsBuilder)
        {
            optionsBuilder.UseSqlServer(@"Server=DESKTOP-3QOB1P9\SQLSERVERHNM2022;Database=BookDB;Trusted_Connection=True;ConnectRetryCount=0;TrustServerCertificate=True");
        }

        public DbSet<Book> Books { get; set; }
    }
}
